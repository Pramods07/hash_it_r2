from django.db import models
# from django.forms import CharField, DecimalField
from django.db.models import CharField,IntegerField,DecimalField,UUIDField
from uuid import uuid4

class Alien(models.Model):
    id = UUIDField(default=uuid4, primary_key=True, editable=False)
    name = CharField(max_length=100,blank=False)
    age = IntegerField()
    native_planet=CharField(max_length=100,blank=False)
    weight=DecimalField(max_digits=6,decimal_places=2)
    height=DecimalField(max_digits=6,decimal_places=2)
    language=CharField(max_length=50,blank=False)

    def __str__(self):
        return self.name

    class Meta:
        ordering=['name']
