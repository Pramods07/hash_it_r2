from django.urls import path
from component import views


urlpatterns = [
    path('create_alien',views.create_alien),
    path('get_aliens',views.get_aliendata),
    path('alien_modify/<str:pk>',views.alien_detail)
]
