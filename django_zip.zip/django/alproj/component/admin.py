from django.contrib import admin
from .models import Alien


admin.site.register(Alien)
# Register your models here.
# pip install -r requiremnt.txt
# usernmae: admin_nod password:admin_nod
# aws: allow inbound: allow port 8000, and outboud:allow port 8000 